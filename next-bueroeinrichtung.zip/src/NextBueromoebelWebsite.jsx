import React from "react";

export default function NextBueromoebelWebsite() {
  return (
    <div className="font-sans text-gray-800">
      <section className="bg-gray-100 py-16 text-center px-6">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">NEXT Büroeinrichtung</h1>
        <p className="text-lg md:text-xl mb-6 max-w-2xl mx-auto">
          Der Arbeitsplatz der Zukunft: ergonomisch, elektrisch, smart.
        </p>
        <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-md text-lg">
          Jetzt konfigurieren
        </button>
      </section>
    </div>
  );
}
