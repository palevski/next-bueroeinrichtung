import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import NextBueromoebelWebsite from './NextBueromoebelWebsite';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <NextBueromoebelWebsite />
  </React.StrictMode>
);
